# DPLang 设计文档 v1.1

DPLang 是一个高性能的领域化专用脚本语言，专门为金融分析设计，使用rust语言实现。

## 1. 脚本执行过程

```执行过程
开始
↓
初始化阶段：
  - 加载所有包脚本，构建函数注册表
  - 执行包级别初始化代码
  - 类型检查和语法验证
↓
数据流处理阶段：
   对于每个脚本：
      验证INPUT/OUTPUT类型匹配
      对于数据流中的每一行：
         创建新的执行上下文（清空局部状态）
         执行当前脚本
         如果返回非NULL：添加到新数据流
         否则：过滤掉该行
      将新数据流传递给下一个脚本
↓
结束（可选聚合阶段）
```

## 2. 脚本特性

1. 脚本类自然语言，人类阅读友好，支持中文变量名和函数名
2. 脚本轻量，执行速度快，内置常用指标，可扩展
3. 脚本可编译成字节码，解释器可编译成wasm 方便集成
4. 脚本语法简单明确，AI学习成本低，节省token
5. 脚本自带垃圾回收机制，防止内存泄漏，自带故障感知，防止程序卡死或超量占用系统资源
6. 脚本可多线程执行
7. 强类型，自动类型推断，自动类型提升（int→float→decimal），保证数据安全的同时，最大化脚本健壮度和编写速度
8. 解释器是白盒，从外部可以获取到公开状态，方便AI操作，提供MCP工具
9. 解释器可以根据脚本生成流程图方便人类理解，未来可以做节点化编程
10. 执行前错误检测：类型检查、未定义变量检查、函数签名验证

## 3. 脚本语法

### 3.1 基本语法

脚本以行为单位，每个行为一个完整的语句，无需分号

```DPLang
# 这是注释
# datafeed 输入的数据行是 [code, 股票名, open, close, high, low, volume]

-- INPUT code:string, 股票名:string, open:float, close:float, high:float, low:float, volume:int --
-- OUTPUT code:string, 股票名:string, close:float, ma5:float, ma10:float --

# 使用 let 关键字定义局部变量
let ma5 = MA(close, 5)
let ma10 = MA(close, 10)

# 使用 return 关键字明确返回，返回数组表示输出数据行
return [code, 股票名, close, ma5, ma10]
```

### 3.2 变量声明

```DPLang
# 局部变量：使用 let 关键字，仅在当前数据行执行上下文有效
let ma5 = MA(close, 5)
let 涨跌幅 = (close - open) / open * 100

# 内置变量
_args      # 当前输入数据行的所有字段（只读）
_index     # 当前数据行索引（从0开始）
_total     # 总数据行数
```

### 3.3 条件分支

```DPLang
# if-else 语句（else可选）
let ma5 = MA(close, 5)
let ma10 = MA(close, 10)

if ma5 > ma10:
    return [code, 股票名, close, ma5, ma10]
else:
    return NULL

# 省略else，默认返回NULL
if ma5 > ma10:
    return [code, 股票名, close, ma5, ma10]

# 三元表达式
let 信号 = ma5 > ma10 ? "买入" : "观望"
let result = ma5 > ma10 ? [code, 股票名, close, ma5, ma10] : NULL
return result
```

### 3.4 数据引用（时间序列）

使用明确的函数代替复杂的切片语法，避免歧义：

```DPLang
# 获取历史数据（不包含当前行）
let 过去5天 = past(close, 5)           # 返回数组，长度5，不足用NULL填充
let 过去5天含今天 = past(close, 5, true)  # 返回数组，长度6，包含当前行

# 获取未来数据（不包含当前行）
let 未来5天 = future(close, 5)         # 返回数组，长度5，不足用NULL填充

# 获取特定偏移的单个值
let 昨天收盘 = offset(close, -1)       # 前1天，返回单个值或NULL
let 前5天收盘 = offset(close, -5)      # 前5天
let 明天收盘 = offset(close, 1)        # 后1天（不推荐使用未来数据）

# 获取窗口数据
let 窗口数据 = window(close, -2, 2)    # 前2天+当前+后2天，返回数组长度5

# 从数据流开始到当前行的所有数据
let 全部历史 = past(close, _index, true)
```

### 3.5 向量运算

```DPLang
# 向量与向量运算（逐元素）
[1, 2, 3] + [4, 5, 6]           # [5, 7, 9]
[1, 2, 3] > [4, 5, 6]           # [false, false, false]
[1, 2, 3] * [2, 3, 4]           # [2, 6, 12]

# 向量与标量运算（广播）
[1, 2, 3] + 1                   # [2, 3, 4]
[1, 2, 3] > 1                   # [false, true, true]
[1, 2, 3] * 2                   # [2, 4, 6]

# 逻辑运算
[1, 2, 3] and [4, 5, 6]         # [true, true, true]（非零即true）
[1, 0, 3] or [0, 5, 0]          # [true, true, true]
not [0, 1, 0]                   # [true, false, true]
```

### 3.6 解构语法

```DPLang
# 数组解构
let [a, b, c] = [1, 2, 3]

# 展开运算符（用于返回时保留原有字段）
let new_field = 100
return [..._args, new_field]    # 保留所有输入字段，添加新字段

# 部分解构
let [code, name, ...rest] = _args
return [code, name, new_field]
```

### 3.7 包（Package）系统

包脚本是独立文件，在所有数据处理脚本执行前加载一次：

```DPLang
# 文件：utils.dpl
# 声明包名，如果省略则函数直接挂载到全局
package 工具包

# 包级常量（解释器启动时初始化一次，所有数据行共享）
const PI = 3.14159
const 涨停阈值 = 0.1

# 私有变量（以_开头，包外不可访问）
const _内部配置 = 100

# 函数定义（自动挂载到包命名空间）
fn A大于B(a, b):
    return a > b

fn 计算涨跌幅(open, close):
    return (close - open) / open * 100

# 带类型签名的函数（可选，用于编译期检查）
fn 安全除法(a:float, b:float, default:float = 0.0) -> float:
    return b != 0 ? a / b : default
```

在数据处理脚本中使用包：

```DPLang
-- INPUT code:string, open:float, close:float --
-- OUTPUT code:string, 涨跌幅:float, 是否涨停:bool --

# 调用包函数
let 涨跌幅 = 工具包.计算涨跌幅(open, close)
let 是否涨停 = 涨跌幅 > 工具包.涨停阈值

# 如果包名为空，直接调用函数
let result = 安全除法(10, 0, default=0)

return [code, 涨跌幅, 是否涨停]
```

### 3.8 关键字

```DPLang
# 核心关键字（英文，不可自定义映射）
let             # 局部变量声明
const           # 常量声明（包级别）
fn              # 函数定义
return          # 返回语句
if, else        # 条件分支
package         # 包声明
NULL            # 空值

# 运算符
+, -, *, /, %, ^              # 算术运算
>, <, >=, <=, ==, !=          # 比较运算
and, or, not                  # 逻辑运算
? :                           # 三元运算

# 保留字（未来扩展）
for, while, break, continue   # 保留但不实现（不支持循环）
import, export                # 保留用于模块系统
```

### 3.9 类型系统

#### 3.9.1 基础类型

```DPLang
int         # 整数：1, -100, 0
float       # 浮点数：1.5, -3.14, 1e-5
decimal     # 高精度十进制（金融计算）：100.00
string      # 字符串："hello", '世界'
bool        # 布尔值：true, false
null        # 空值：NULL
array       # 数组：[1, 2, 3]
```

#### 3.9.2 类型自动提升

```DPLang
int + int       → int
int + float     → float
float + float   → float
int + decimal   → decimal
float + decimal → decimal

# 示例
let a = 1           # int
let b = 1.5         # float
let c = a + b       # float (自动提升)
```

#### 3.9.3 类型检查函数

```DPLang
# 运行时类型检查
typeis(value, "int")        # 返回 bool
typeis(value, "float")
typeis(value, "string")
typeis(value, "bool")
typeis(value, "null")
typeis(value, "array")

# 类型转换
to_int(value)               # 转换为整数，失败返回NULL
to_float(value)             # 转换为浮点数
to_string(value)            # 转换为字符串
to_decimal(value)           # 转换为高精度十进制
```

#### 3.9.4 输入输出类型约束

```DPLang
# 编译期类型检查（必须在脚本开头）
-- INPUT code:string, close:float, volume:int --
-- OUTPUT code:string, signal:string, score:float --

# 如果输入数据类型不匹配，脚本加载失败
# 如果输出数据类型不匹配，编译期报错
```

### 3.10 错误处理

采用统一的宏注释方式处理错误，避免try-catch增加控制流复杂度：

```DPLang
-- INPUT code:string, open:float, close:float --
-- OUTPUT code:string, 涨跌幅:float --

# 遇到任何运行时错误（除零、NULL引用等）返回NULL，过滤该行
-- ON_ERROR NULL --

# 或者返回特定的错误行（需要匹配OUTPUT结构）
-- ON_ERROR ["ERROR", 0.0] --

let 涨跌幅 = (close - open) / open  # 如果open为0，触发错误处理

return [code, 涨跌幅]
```

使用安全函数避免错误：

```DPLang
# 内置安全函数（返回NULL或默认值，不抛出错误）
let result = safe_div(a, b)                    # 除零返回NULL
let result = safe_div(a, b, default=0.0)       # 除零返回0.0
let value = safe_get(array, index)             # 越界返回NULL
let value = safe_get(array, index, default=0)  # 越界返回0
```

### 3.11 内置函数

```DPLang
# 数学函数
abs(x)              # 绝对值
max(a, b, ...)      # 最大值
min(a, b, ...)      # 最小值
sum([1, 2, 3])      # 求和
mean([1, 2, 3])     # 平均值
sqrt(x)             # 平方根
pow(x, y)           # 幂运算

# 数组函数
len(array)          # 数组长度
first(array)        # 第一个元素
last(array)         # 最后一个元素
filter(array, fn)   # 过滤（需要包中定义fn）
map(array, fn)      # 映射

# 时间序列函数（前面已说明）
past(field, n, include_current=false)
future(field, n)
offset(field, n)
window(field, start, end)

# 技术分析函数（需加载TA包）
MA(close, period)           # 移动平均
EMA(close, period)          # 指数移动平均
MACD(close, fast, slow, signal)
RSI(close, period)
BOLL(close, period, std)
```

## 4. 完整示例

### 示例1：简单过滤

```DPLang
-- INPUT code:string, name:string, close:float --
-- OUTPUT code:string, name:string, close:float --
-- ON_ERROR NULL --

# 只保留收盘价大于10的股票
if close > 10:
    return _args
else:
    return NULL

# 或者更简洁
return close > 10 ? _args : NULL
```

### 示例2：计算技术指标

```DPLang
-- INPUT code:string, name:string, close:float --
-- OUTPUT code:string, name:string, close:float, ma5:float, ma10:float, signal:string --
-- ON_ERROR NULL --

let ma5 = MA(close, 5)
let ma10 = MA(close, 10)
let signal = ma5 > ma10 ? "金叉" : "死叉"

return [code, name, close, ma5, ma10, signal]
```

### 示例3：使用历史数据

```DPLang
-- INPUT code:string, close:float --
-- OUTPUT code:string, 涨幅:float, 是否新高:bool --
-- ON_ERROR NULL --

# 获取过去20天的收盘价
let 历史20天 = past(close, 20, true)

# 计算涨幅
let 昨收 = offset(close, -1)
let 涨幅 = safe_div(close - 昨收, 昨收, default=0.0) * 100

# 判断是否创20日新高
let 最高价 = max(...历史20天)
let 是否新高 = close >= 最高价

return [code, 涨幅, 是否新高]
```

### 示例4：自定义包

```DPLang
# 文件：my_indicators.dpl
package 指标

const 短期周期 = 5
const 长期周期 = 10

fn 计算双均线信号(close:float) -> string:
    let ma_short = MA(close, 短期周期)
    let ma_long = MA(close, 长期周期)
    
    let 昨日短均 = offset(ma_short, -1)
    let 昨日长均 = offset(ma_long, -1)
    
    # 金叉
    if 昨日短均 <= 昨日长均 and ma_short > ma_long:
        return "金叉"
    
    # 死叉
    if 昨日短均 >= 昨日长均 and ma_short < ma_long:
        return "死叉"
    
    return "持有"

fn 计算强度(close:float, volume:int) -> float:
    let 涨幅 = safe_div(close - offset(close, -1), offset(close, -1), default=0.0)
    let 量比 = safe_div(volume, mean(past(volume, 5)), default=1.0)
    return 涨幅 * 量比
```

在数据脚本中使用：

```DPLang
-- INPUT code:string, close:float, volume:int --
-- OUTPUT code:string, signal:string, strength:float --
-- ON_ERROR NULL --

let signal = 指标.计算双均线信号(close)
let strength = 指标.计算强度(close, volume)

return [code, signal, strength]
```

## 5. 执行前错误检测

解释器在执行前会进行以下检查：

### 5.1 语法检查
- 关键字拼写错误
- 括号匹配
- 缩进一致性

### 5.2 类型检查
- INPUT/OUTPUT 类型声明匹配
- 函数签名类型匹配（如果有类型标注）
- 返回值类型与OUTPUT声明一致

### 5.3 语义检查
- 未定义变量引用
- 函数未定义
- 包不存在
- 重复变量定义
- 返回语句位置（必须在控制流末尾）

### 5.4 示例错误检测

```DPLang
-- INPUT code:string, close:float --
-- OUTPUT code:string, result:float --

let ma5 = MA(close, 5)
let result = ma5 + undefined_var    # ❌ 编译错误：undefined_var 未定义

return [code, result, extra]        # ❌ 编译错误：OUTPUT只声明2个字段

let ma5 = MA(close, "abc")          # ❌ 类型错误：MA期望int类型周期参数

return result                       # ❌ 编译错误：返回值应该是数组类型
```

## 6. 与v1.0的主要变更

1. ✅ **引入明确的return关键字**，消除返回语法歧义
2. ✅ **引入let关键字**，明确局部变量声明
3. ✅ **简化数据引用**，使用函数（past/future/offset/window）替代复杂切片
4. ✅ **移除try-catch**，统一使用-- ON_ERROR --宏和安全函数
5. ✅ **移除关键字映射**，核心关键字统一使用英文
6. ✅ **明确包初始化语义**，使用const声明包级常量
7. ✅ **增强类型系统**，明确类型提升规则
8. ✅ **增加完整示例**，覆盖常见场景
9. ✅ **明确错误检测能力**，列出编译期可检测的错误类型

## 7. 工具链支持（规划）

- **LSP**：语法高亮、自动补全、错误提示
- **格式化工具**：统一代码风格
- **类型检查器**：独立的类型验证工具
- **流程图生成**：可视化脚本逻辑
- **REPL**：交互式开发环境
- **包管理器**：包的发布和依赖管理
