# DPLang 设计文档 v1.2

DPLang 是一个高性能的领域化专用脚本语言，专门为金融分析设计，使用rust语言实现。

## 1. 脚本执行过程

```执行过程
开始
↓
初始化阶段：
  - 加载所有包脚本，执行包级变量初始化
  - 构建函数注册表（公开/私有函数）
  - 类型检查和语法验证
  - 变量遮蔽检测
↓
数据流处理阶段：
   对于每个数据处理脚本：
      验证INPUT/OUTPUT类型匹配
      对于数据流中的每一行：
         创建新的执行上下文（清空局部变量）
         执行当前脚本
         如果返回非NULL：添加到新数据流
         否则：过滤掉该行
         销毁执行上下文（释放局部变量）
      将新数据流传递给下一个脚本
↓
结束（可选聚合阶段）
```

## 2. 脚本特性

1. 脚本类自然语言，人类阅读友好，支持中文变量名和函数名
2. 脚本轻量，执行速度快，内置常用指标，可扩展
3. 脚本可编译成字节码，解释器可编译成wasm方便集成
4. 脚本语法极简明确，AI学习成本低，节省token
5. 脚本自带垃圾回收机制，无闭包设计，GC压力小，内存管理简单
6. 脚本可多线程执行
7. 统一number类型，自动位宽/类型提升，保证安全的同时最大化健壮度
8. 完全禁止变量遮蔽，编译期可检测所有作用域错误
9. 解释器是白盒，从外部可以获取到公开状态，方便AI操作，提供MCP工具
10. 解释器可以根据脚本生成流程图方便人类理解，未来可以做节点化编程
11. 执行前错误检测：类型检查、未定义变量、变量遮蔽、私有成员访问、函数签名验证

## 3. 核心设计原则

### 3.1 变量不可变性
- **数据脚本**：所有变量默认不可变，无需关键字声明
- **包脚本**：默认不可变，使用 `mut` 声明可变状态

### 3.2 无变量遮蔽
- 完全禁止变量遮蔽，编译期报错
- 简化作用域分析，减少GC负担

### 3.3 无闭包特性
- 函数内变量完全隔离，函数返回后立即释放
- 无需追踪闭包引用链，GC实现简单高效

### 3.4 访问控制
- `_` 前缀表示私有（函数、变量）
- 默认公开访问
- 只有包脚本可以定义函数

## 4. 脚本语法

### 4.1 基本语法

脚本以行为单位，每个行为一个完整的语句，无需分号

```DPLang
# 这是注释
# datafeed 输入的数据行是 [code, 股票名, open, close, high, low, volume]

-- INPUT code:string, 股票名:string, open:number, close:number, high:number, low:number, volume:number --
-- OUTPUT code:string, 股票名:string, close:number, ma5:number, ma10:number --

# 变量赋值（不可变，无需关键字）
ma5 = MA(close, 5)
ma10 = MA(close, 10)

# 使用 return 关键字明确返回
return [code, 股票名, close, ma5, ma10]
```

### 4.2 数据处理脚本

数据处理脚本在每行数据上执行，所有变量都是局部变量，执行完毕后立即释放

```DPLang
-- INPUT code:string, close:number --
-- OUTPUT code:string, signal:string --

# 局部变量（执行完自动释放）
ma5 = MA(close, 5)
ma10 = MA(close, 10)

# ❌ 错误：变量遮蔽
# ma5 = ma5 * 2  # 编译错误：ma5已定义

# ✅ 正确：使用新变量名
ma5_adjusted = ma5 * 2

# ❌ 错误：数据脚本不能定义函数
# 计算信号():  # 编译错误
#     return "买入"

signal = ma5 > ma10 ? "金叉" : "死叉"

return [code, signal]
```

### 4.3 包脚本

包脚本在解释器启动时执行一次，用于定义函数和包级变量

```DPLang
package 工具包

# ========== 包级变量 ==========

# 公开常量（不可变）
涨停阈值 = 0.1
短期周期 = 5
长期周期 = 10

# 私有常量（包外不可访问）
_内部配置 = 100
_调试模式 = false

# 公开可变状态（需要 mut 关键字）
mut 调用次数 = 0
mut 错误计数 = 0

# 私有可变状态
mut _缓存数据 = []
mut _最后更新时间 = 0

# ========== 函数定义 ==========

# 公开函数（无需fn关键字，通过括号识别）
计算涨跌幅(open:number, close:number) -> number:
    涨幅 = (close - open) / open * 100
    
    # 修改包级可变状态（只能在包内修改）
    调用次数 = 调用次数 + 1
    
    return 涨幅
    # 注意：涨幅变量在return后立即销毁

# 私有函数（包外不可访问）
_内部辅助计算(x:number) -> number:
    temp = x * 2
    result = temp + _内部配置
    return result
    # temp和result在return后销毁

# 不带类型签名的函数（类型推断）
判断涨停(涨幅):
    return 涨幅 >= 涨停阈值

# 使用私有函数
计算复杂指标(value:number) -> number:
    中间结果 = _内部辅助计算(value)
    最终结果 = 中间结果 * 短期周期
    return 最终结果
```

在数据脚本中使用包：

```DPLang
-- INPUT code:string, open:number, close:number --
-- OUTPUT code:string, 涨幅:number, 是否涨停:bool --

# ✅ 调用公开函数
涨幅 = 工具包.计算涨跌幅(open, close)

# ✅ 访问公开常量
阈值 = 工具包.涨停阈值

# ✅ 读取公开可变状态
次数 = 工具包.调用次数

# ❌ 错误：访问私有成员
# config = 工具包._内部配置  # 编译错误：私有变量
# result = 工具包._内部辅助计算(10)  # 编译错误：私有函数

# ❌ 错误：修改包级状态（只能在包内修改）
# 工具包.调用次数 = 0  # 编译错误：只有包内可修改mut变量

是否涨停 = 工具包.判断涨停(涨幅)

return [code, 涨幅, 是否涨停]
```

### 4.4 条件分支

```DPLang
# if-else 语句（else可选）
ma5 = MA(close, 5)
ma10 = MA(close, 10)

if ma5 > ma10:
    return [code, 股票名, close, ma5, ma10]
else:
    return null

# 省略else，默认返回null
if ma5 > ma10:
    return [code, 股票名, close, ma5, ma10]

# 三元表达式
信号 = ma5 > ma10 ? "买入" : "观望"
result = ma5 > ma10 ? [code, close] : null
return result

# 嵌套条件
if close > offset(close, -1):
    if volume > offset(volume, -1):
        return [code, "放量上涨"]
    else:
        return [code, "缩量上涨"]
else:
    return null
```

### 4.5 数据引用（时间序列）

使用明确的函数代替复杂的切片语法：

```DPLang
# 获取历史数据（不包含当前行）
过去5天 = past(close, 5)              # 返回数组[5个元素]，不足用null填充
过去5天含今天 = past(close, 5, true)   # 返回数组[6个元素]，包含当前行

# 获取未来数据（不包含当前行，不推荐）
未来5天 = future(close, 5)            # 返回数组[5个元素]，不足用null填充

# 获取特定偏移的单个值
昨天收盘 = offset(close, -1)          # 返回单个值或null
前5天收盘 = offset(close, -5)
明天收盘 = offset(close, 1)           # 不推荐使用未来数据

# 获取窗口数据
窗口数据 = window(close, -2, 2)       # 前2天+当前+后2天，返回数组[5个元素]

# 从数据流开始到当前行
全部历史 = past(close, _index, true)  # _index是内置变量

# 实际应用示例
昨收 = offset(close, -1)
今涨幅 = (close - 昨收) / 昨收 * 100

历史5天 = past(close, 5, true)
5日均价 = mean(历史5天)
是否新高 = close >= max(...历史5天)
```

### 4.6 向量运算

```DPLang
# 向量与向量运算（逐元素）
[1, 2, 3] + [4, 5, 6]           # [5, 7, 9]
[1, 2, 3] > [4, 5, 6]           # [false, false, false]
[1, 2, 3] * [2, 3, 4]           # [2, 6, 12]

# 向量与标量运算（广播）
[1, 2, 3] + 1                   # [2, 3, 4]
[1, 2, 3] > 1                   # [false, true, true]
[1, 2, 3] * 2                   # [2, 4, 6]

# 逻辑运算（非零即true）
[1, 2, 3] and [4, 5, 6]         # [true, true, true]
[1, 0, 3] or [0, 5, 0]          # [true, true, true]
not [0, 1, 0]                   # [true, false, true]

# 实际应用
历史收盘 = past(close, 20, true)
历史涨幅 = (历史收盘 - offset(历史收盘, -1)) / offset(历史收盘, -1)
上涨天数 = sum(历史涨幅 > 0)
```

### 4.7 解构语法

```DPLang
# 数组解构
[a, b, c] = [1, 2, 3]

# 函数返回值解构
[dif, dea, macd] = MACD(close, 12, 26, 9)

# 展开运算符（用于返回时保留原有字段）
新字段 = 100
return [..._args, 新字段]    # 保留所有输入字段，添加新字段

# 部分解构
[code, name, ...rest] = _args
return [code, name, 新字段]

# 忽略部分字段
[code, _, close] = _args     # _ 表示忽略该字段
```

### 4.8 内置变量

```DPLang
_args      # 当前输入数据行的所有字段（只读数组）
_index     # 当前数据行索引（从0开始）
_total     # 总数据行数
_fields    # 输入字段名数组

# 示例
当前是第几行 = _index + 1
是否最后一行 = _index == _total - 1
输入字段数 = len(_fields)
```

### 4.9 关键字

```DPLang
# 核心关键字（不可用作变量名）
return          # 返回语句
if, else        # 条件分支
package         # 包声明
mut             # 可变状态声明（仅包级变量）
null            # 空值
true, false     # 布尔值

# 运算符
+, -, *, /, %, ^              # 算术运算
>, <, >=, <=, ==, !=          # 比较运算
and, or, not                  # 逻辑运算
? :                           # 三元运算
...                           # 展开运算符

# 保留字（未来可能使用）
for, while, break, continue   # 保留但不实现（不支持循环）
import, export                # 保留用于模块系统
let, const, var, fn           # 保留（避免与其他语言混淆）
```

## 5. 类型系统

### 5.1 基础类型

```DPLang
number      # 统一数值类型（底层自动选择表示）
decimal     # 高精度十进制（金融计算专用）
string      # 字符串
bool        # 布尔值
null        # 空值
array       # 数组
```

### 5.2 number 类型自动提升

```DPLang
# 位宽自动提升（防溢出）
a = 100                    # number (底层int32)
b = 10000000000            # number (底层int64，自动提升)
c = a + b                  # number (底层int64)

# 类型自动提升（int → float）
x = 10                     # number (底层int)
y = 3                      # number (底层int)
z = x / y                  # number (底层float64: 3.333...)

# 显式整数除法
整数结果 = floor(x / y)     # 3
整数结果2 = int(x / y)      # 3（截断小数）

# 精度提升（number → decimal）
价格 = 100.12              # number (底层float64)
精确价格 = decimal(100.12)  # decimal (高精度)
总金额 = 精确价格 * 1000    # decimal (保持高精度)
```

### 5.3 类型转换函数

```DPLang
# 显式转换
int(3.14)           # 3 (截断小数)
floor(3.14)         # 3 (向下取整)
ceil(3.14)          # 4 (向上取整)
round(3.14)         # 3 (四舍五入)
round(3.56)         # 4

decimal("100.12")   # decimal类型
string(123)         # "123"
number("123.45")    # 123.45

# 类型检查
typeis(value, "number")
typeis(value, "decimal")
typeis(value, "string")
typeis(value, "bool")
typeis(value, "null")
typeis(value, "array")
```

### 5.4 输入输出类型约束

```DPLang
# 完整类型声明
-- INPUT code:string, close:number, volume:number --
-- OUTPUT code:string, signal:string, score:number --

# 类型推断（从数据自动推断，更激进的简化）
-- INPUT code, close, volume --
-- OUTPUT code, signal, score --

# 混合模式（部分声明）
-- INPUT code:string, close, volume --  # code明确为string，其他推断

# decimal 精度模式
-- INPUT price:decimal, amount:decimal --
-- PRECISION decimal --  # 整个脚本使用decimal计算
```

## 6. 错误处理

### 6.1 宏注释错误处理

采用统一的宏注释方式，避免try-catch增加控制流复杂度：

```DPLang
-- INPUT code:string, open:number, close:number --
-- OUTPUT code:string, 涨跌幅:number --

# 遇到任何运行时错误返回null（过滤该行）
-- ON_ERROR null --

涨跌幅 = (close - open) / open  # 如果open为0，触发错误，返回null

return [code, 涨跌幅]
```

```DPLang
# 返回特定的错误行（需要匹配OUTPUT结构）
-- ON_ERROR ["ERROR", 0.0] --

涨跌幅 = (close - open) / open

return [code, 涨跌幅]
```

### 6.2 安全函数

使用内置安全函数避免错误，返回null或默认值：

```DPLang
# 安全除法
result = safe_div(a, b)                    # 除零返回null
result = safe_div(a, b, default=0.0)       # 除零返回0.0

# 安全数组访问
value = safe_get(array, index)             # 越界返回null
value = safe_get(array, index, default=0)  # 越界返回0

# 安全类型转换
num = safe_number("abc")                   # 转换失败返回null
num = safe_number("abc", default=0)        # 转换失败返回0

# 实际应用
昨收 = offset(close, -1)
涨幅 = safe_div(close - 昨收, 昨收, default=0.0) * 100
```

## 7. 内置函数

### 7.1 数学函数

```DPLang
abs(x)              # 绝对值
max(a, b, ...)      # 最大值（可变参数）
min(a, b, ...)      # 最小值
sum([1, 2, 3])      # 数组求和: 6
sum(1, 2, 3)        # 可变参数求和: 6
mean([1, 2, 3])     # 平均值: 2
median([1, 2, 3])   # 中位数: 2
sqrt(x)             # 平方根
pow(x, y)           # x的y次方
log(x)              # 自然对数
log10(x)            # 以10为底的对数
exp(x)              # e的x次方

# 取整函数
floor(x)            # 向下取整
ceil(x)             # 向上取整
round(x)            # 四舍五入
int(x)              # 截断小数部分
```

### 7.2 数组函数

```DPLang
len(array)                  # 数组长度
first(array)                # 第一个元素
last(array)                 # 最后一个元素
reverse(array)              # 反转数组
sort(array)                 # 排序（升序）
sort(array, desc=true)      # 降序排序
unique(array)               # 去重
concat(arr1, arr2)          # 连接数组

# 数组统计
count(array, value)         # 统计value出现次数
count_if(array, condition)  # 统计满足条件的元素（需要包函数）
```

### 7.3 时间序列函数

```DPLang
past(field, n, include_current=false)   # 历史数据
future(field, n)                        # 未来数据
offset(field, n)                        # 偏移数据
window(field, start, end)               # 窗口数据
```

### 7.4 技术分析函数（需加载TA包）

```DPLang
# 移动平均
MA(close, period)               # 简单移动平均
EMA(close, period)              # 指数移动平均
SMA(close, period)              # 同MA
WMA(close, period)              # 加权移动平均

# 趋势指标
MACD(close, fast, slow, signal) # 返回[dif, dea, macd]
KDJ(high, low, close, n, m1, m2) # 返回[k, d, j]
RSI(close, period)              # 相对强弱指标
BOLL(close, period, std)        # 返回[upper, middle, lower]

# 成交量指标
OBV(close, volume)              # 能量潮
VOLUME_MA(volume, period)       # 成交量均线

# 其他指标
ATR(high, low, close, period)   # 真实波幅
CCI(high, low, close, period)   # 顺势指标
```

### 7.5 安全函数

```DPLang
safe_div(a, b, default=null)        # 安全除法
safe_get(array, index, default=null) # 安全数组访问
safe_number(value, default=null)    # 安全类型转换
safe_decimal(value, default=null)   # 安全decimal转换
```

## 8. 完整示例

### 示例1：简单过滤

```DPLang
-- INPUT code:string, name:string, close:number --
-- OUTPUT code:string, name:string, close:number --
-- ON_ERROR null --

# 只保留收盘价大于10的股票
if close > 10:
    return _args
else:
    return null

# 更简洁的写法
return close > 10 ? _args : null
```

### 示例2：计算技术指标

```DPLang
-- INPUT code:string, name:string, close:number --
-- OUTPUT code:string, name:string, close:number, ma5:number, ma10:number, signal:string --
-- ON_ERROR null --

ma5 = MA(close, 5)
ma10 = MA(close, 10)
signal = ma5 > ma10 ? "金叉" : "死叉"

return [code, name, close, ma5, ma10, signal]
```

### 示例3：使用历史数据

```DPLang
-- INPUT code:string, close:number, volume:number --
-- OUTPUT code:string, 涨幅:number, 是否新高:bool, 量比:number --
-- ON_ERROR null --

# 获取历史数据
昨收 = offset(close, -1)
历史20天 = past(close, 20, true)
历史5日成交量 = past(volume, 5)

# 计算指标
涨幅 = safe_div(close - 昨收, 昨收, default=0.0) * 100
最高价 = max(...历史20天)
是否新高 = close >= 最高价
平均成交量 = mean(历史5日成交量)
量比 = safe_div(volume, 平均成交量, default=1.0)

return [code, 涨幅, 是否新高, 量比]
```

### 示例4：复杂条件筛选

```DPLang
-- INPUT code:string, close:number, volume:number, pe:number --
-- OUTPUT code:string, 评级:string, 分数:number --
-- ON_ERROR null --

# 计算基础指标
ma5 = MA(close, 5)
ma10 = MA(close, 10)
昨收 = offset(close, -1)
涨幅 = safe_div(close - 昨收, 昨收, default=0.0) * 100

# 评分系统
分数 = 0
分数 = ma5 > ma10 ? 分数 + 30 : 分数
分数 = 涨幅 > 0 ? 分数 + 20 : 分数
分数 = pe > 0 and pe < 20 ? 分数 + 30 : 分数
分数 = volume > mean(past(volume, 5)) ? 分数 + 20 : 分数

# 评级
评级 = "D"
if 分数 >= 80:
    评级 = "A"
else:
    if 分数 >= 60:
        评级 = "B"
    else:
        if 分数 >= 40:
            评级 = "C"

# 只返回评级B以上的股票
return 分数 >= 60 ? [code, 评级, 分数] : null
```

### 示例5：自定义包

```DPLang
# 文件：my_indicators.dpl
package 指标库

# ========== 包级常量 ==========
默认短期 = 5
默认长期 = 10
默认信号周期 = 20

# 私有配置
_调试模式 = false
_最大缓存 = 1000

# ========== 包级状态 ==========
mut 调用统计 = 0
mut 错误计数 = 0
mut _缓存 = []

# ========== 公开函数 ==========

# 双均线信号
双均线信号(close:number, 短期:number, 长期:number) -> string:
    ma_short = MA(close, 短期)
    ma_long = MA(close, 长期)
    
    昨日短均 = offset(ma_short, -1)
    昨日长均 = offset(ma_long, -1)
    
    调用统计 = 调用统计 + 1
    
    # 金叉
    if 昨日短均 <= 昨日长均 and ma_short > ma_long:
        return "金叉"
    
    # 死叉
    if 昨日短均 >= 昨日长均 and ma_short < ma_long:
        return "死叉"
    
    return "持有"

# 便捷函数（使用默认参数）
快速双均线(close:number) -> string:
    return 双均线信号(close, 默认短期, 默认长期)

# 综合强度（价格+成交量）
计算强度(close:number, volume:number) -> number:
    昨收 = offset(close, -1)
    涨幅 = safe_div(close - 昨收, 昨收, default=0.0)
    
    历史成交量 = past(volume, 5)
    量比 = safe_div(volume, mean(历史成交量), default=1.0)
    
    强度 = 涨幅 * 量比
    
    return _标准化强度(强度)

# 突破信号
突破信号(close:number, 周期:number) -> bool:
    历史数据 = past(close, 周期, true)
    最高价 = max(...历史数据)
    
    # 今日收盘突破历史最高
    return close > 最高价

# ========== 私有函数 ==========

_标准化强度(强度:number) -> number:
    # 将强度映射到0-100
    标准化值 = (强度 + 1) * 50
    标准化值 = max(0, min(100, 标准化值))
    return 标准化值

_清理缓存():
    _缓存 = []
    return null

_记录错误(错误信息:string):
    错误计数 = 错误计数 + 1
    if _调试模式:
        # 这里可以记录日志
        return null
    return null
```

在数据脚本中使用：

```DPLang
-- INPUT code:string, close:number, volume:number --
-- OUTPUT code:string, 信号:string, 强度:number, 是否突破:bool --
-- ON_ERROR null --

# 使用包函数
信号 = 指标库.快速双均线(close)
强度 = 指标库.计算强度(close, volume)
是否突破 = 指标库.突破信号(close, 20)

# 访问包常量
短期周期 = 指标库.默认短期

# 读取调用统计
调用次数 = 指标库.调用统计

# 只返回有信号的股票
return 信号 != "持有" ? [code, 信号, 强度, 是否突破] : null
```

### 示例6：高精度金融计算

```DPLang
-- INPUT code:string, price:decimal, shares:number --
-- OUTPUT code:string, 总金额:decimal, 手续费:decimal, 实付:decimal --
-- PRECISION decimal --  # 使用高精度模式
-- ON_ERROR null --

# decimal类型保证精度
手续费率 = decimal(0.0003)  # 万三手续费
印花税率 = decimal(0.001)   # 千一印花税

# 计算
总金额 = price * shares
手续费 = 总金额 * 手续费率
印花税 = 总金额 * 印花税率
实付 = 总金额 + 手续费 + 印花税

# 四舍五入到分
实付 = round(实付, 2)

return [code, 总金额, 手续费, 实付]
```

## 9. 编译期错误检测

解释器在执行前会进行以下检查：

### 9.1 语法检查
- 关键字拼写错误
- 括号/引号匹配
- 缩进一致性（if/else块）
- return语句位置

### 9.2 类型检查
- INPUT/OUTPUT类型声明匹配
- 函数签名类型匹配（如果有类型标注）
- 返回值类型与OUTPUT声明一致
- 类型转换合法性

### 9.3 作用域检查
- **未定义变量引用**
- **变量遮蔽检测（完全禁止）**
- 函数未定义
- 包不存在
- 私有成员访问检查

### 9.4 语义检查
- 数据脚本不能定义函数
- 只有包内可修改mut变量
- 函数内变量不可外部访问
- 返回值结构与OUTPUT一致

### 9.5 错误示例

```DPLang
# 错误1：变量遮蔽
ma5 = MA(close, 5)
ma5 = ma5 * 2  # ❌ 编译错误：变量 ma5 已定义，禁止遮蔽

# 错误2：未定义变量
result = undefined_var + 1  # ❌ 编译错误：undefined_var 未定义

# 错误3：访问私有成员
value = 工具包._内部变量  # ❌ 编译错误：私有变量不可访问
工具包._私有函数()        # ❌ 编译错误：私有函数不可访问

# 错误4：数据脚本定义函数
计算():  # ❌ 编译错误：只有package脚本可定义函数
    return 1

# 错误5：修改包级状态
工具包.调用次数 = 0  # ❌ 编译错误：只有包内可修改mut变量

# 错误6：类型不匹配
-- OUTPUT code:string, value:number --
return [code, "not a number"]  # ❌ 编译错误：value应为number类型

# 错误7：返回值字段数不匹配
-- OUTPUT code:string, value:number --
return [code, 100, 200]  # ❌ 编译错误：OUTPUT声明2个字段，返回了3个

# 错误8：在非包脚本修改变量
package 工具包
PI = 3.14159
修改PI():
    PI = 3.14  # ❌ 编译错误：PI不可变，需声明为 mut PI
    return null
```

## 10. 作用域和生命周期

### 10.1 作用域层级

```
全局作用域
  └── 包作用域（package）
        ├── 包级变量（解释器启动时初始化，持续到解释器销毁）
        └── 函数作用域
              └── 函数局部变量（函数调用时创建，返回时销毁）
  
数据流作用域（每个数据处理脚本）
  └── 数据行作用域（每行数据）
        └── 局部变量（执行当前行时创建，执行完毕后销毁）
```

### 10.2 生命周期示例

```DPLang
# ========== 包脚本 ==========
package 示例包

# 生命周期：解释器启动 → 解释器销毁
常量A = 100
mut 状态B = 0

# 函数定义：解释器启动时注册
计算(x):
    # 生命周期：函数调用 → 函数返回
    临时变量 = x * 2
    
    # 修改包级状态（生命周期长）
    状态B = 状态B + 1
    
    return 临时变量
    # 临时变量销毁

# ========== 数据脚本 ==========
-- INPUT code:string, close:number --

# 第1行数据执行：
#   ma5 = MA(close, 5)  # 创建
#   return [code, ma5]   # 使用
#   # ma5销毁

# 第2行数据执行：
#   ma5 = MA(close, 5)  # 重新创建（新的变量）
#   return [code, ma5]
#   # ma5销毁

ma5 = MA(close, 5)
return [code, ma5]
```

### 10.3 内存管理优势

```DPLang
# 无闭包 = 简单栈管理
计算指标(close):
    ma5 = MA(close, 5)
    ma10 = MA(close, 10)
    diff = ma5 - ma10
    return diff
    # ma5, ma10, diff 立即从栈弹出，无需GC追踪

# 禁止遮蔽 = 无需版本链
ma5 = MA(close, 5)
# ma5 = ma5 * 2  # ❌ 禁止
ma5_scaled = ma5 * 2  # ✅ 新变量，清晰的内存布局

# 不可变 = 无需拷贝写入（Copy-on-Write）
历史数据 = past(close, 20)  # 只读引用，无需拷贝
最大值 = max(...历史数据)    # 安全读取
```

## 11. 与v1.1的主要变更

1. ✅ **移除 let/const 关键字**：通过位置和mut关键字区分
2. ✅ **移除 fn 关键字**：通过参数列表自然识别函数
3. ✅ **统一为 number 类型**：自动位宽/类型提升，保留decimal用于高精度
4. ✅ **完全禁止变量遮蔽**：编译期检测，简化内存管理
5. ✅ **无闭包设计**：函数内变量完全隔离，GC压力小
6. ✅ **访问控制规范**：`_`前缀表示私有，只有包脚本可定义函数
7. ✅ **mut关键字**：明确可变包级状态
8. ✅ **增强编译期检测**：作用域错误、私有成员访问、变量遮蔽等

## 12. 设计对比总结

| 特性 | v1.0 | v1.1 | v1.2 |
|------|------|------|------|
| 变量声明 | 隐式 | let/const | 无关键字 |
| 函数定义 | fn关键字 | fn关键字 | 无fn（括号识别） |
| 数值类型 | int/float分离 | int/float分离 | number统一 |
| 变量遮蔽 | 允许 | 允许 | 完全禁止 |
| 闭包 | 未定义 | 未定义 | 明确禁止 |
| 可变性 | 未定义 | 默认可变 | 默认不可变 |
| 访问控制 | `_`约定 | `_`约定 | `_`强制+编译检查 |
| 数据切片 | 复杂语法 | 函数化 | 函数化 |
| 错误处理 | try-catch | 宏+安全函数 | 宏+安全函数 |
| Token效率 | 中 | 中 | 高 |
| 语法简洁度 | 中 | 中 | 高 |
| 编译检查 | 基础 | 增强 | 完善 |
| GC复杂度 | 中 | 中 | 低 |

## 13. 工具链支持（规划）

- **LSP**：语法高亮、自动补全、错误提示、跳转定义
- **格式化工具**：统一代码风格
- **Linter**：作用域检查、变量遮蔽检测、私有成员访问检查
- **类型检查器**：独立的静态类型验证工具
- **流程图生成**：可视化脚本逻辑
- **REPL**：交互式开发环境
- **包管理器**：包的发布和依赖管理
- **调试器**：断点、变量查看、包状态监控
- **性能分析器**：识别热点函数、内存分配分析

## 14. 最佳实践

### 14.1 命名规范

```DPLang
# 包级常量：描述性名称
涨停阈值 = 0.1
默认周期 = 20

# 局部变量：简洁明确
ma5 = MA(close, 5)
涨幅 = (close - open) / open

# 私有成员：_前缀
_内部配置 = 100
_辅助计算(x):
    return x * 2

# 函数：动词开头或描述性名称
计算涨跌幅(open, close):
    return (close - open) / open

判断涨停(涨幅):
    return 涨幅 >= 涨停阈值
```

### 14.2 避免变量遮蔽

```DPLang
# ❌ 错误：想要修改变量（会报错）
ma5 = MA(close, 5)
ma5 = ma5 * 2  # 编译错误

# ✅ 正确：使用新变量名
ma5 = MA(close, 5)
ma5_scaled = ma5 * 2

# ✅ 正确：使用有意义的名称
原始ma5 = MA(close, 5)
调整后ma5 = 原始ma5 * 2
```

### 14.3 合理使用包级可变状态

```DPLang
package 统计包

# ✅ 合理：统计信息
mut 调用次数 = 0
mut 错误计数 = 0

# ✅ 合理：缓存
mut _缓存 = []

# ⚠️ 慎用：业务状态（可能导致并发问题）
mut 累计收益 = 0.0  # 如果多线程执行会有问题

# ❌ 不推荐：频繁修改的临时状态
mut _临时计数 = 0  # 应该作为函数参数传递
```

### 14.4 高精度计算

```DPLang
# 金融计算使用decimal
-- PRECISION decimal --

买入价 = decimal(100.123)
卖出价 = decimal(101.456)
股数 = 1000

盈利 = (卖出价 - 买入价) * 股数
# 保持decimal精度，避免浮点误差
```

### 14.5 性能优化

```DPLang
# ✅ 避免重复计算
历史数据 = past(close, 20, true)  # 只计算一次
最大值 = max(...历史数据)
最小值 = min(...历史数据)
平均值 = mean(历史数据)

# ❌ 重复计算（低效）
最大值 = max(...past(close, 20, true))
最小值 = min(...past(close, 20, true))
平均值 = mean(past(close, 20, true))

# ✅ 使用安全函数避免异常
涨幅 = safe_div(close - open, open, default=0.0)

# ❌ 手动检查（冗长）
if open != 0:
    涨幅 = (close - open) / open
else:
    涨幅 = 0.0
```

## 15. 答疑
q. 为什么禁止变量遮蔽
a. 强制数据处理流程简单化，并且每一步操作都要意义明确

q. 包级状态的并发如何处理
a. 在数据处理脚本中禁止修改 外部变量，也就是数据处理脚本是一个无副作用的纯函数，并发不会对全局状态造成影响，包涵数顺序执行，只执行一次也不会全局状态并发造成影响

q. 如何识别函数定义和调用
a. 函数定义会在后面紧跟 ‘:’

q. 时间序列的性能问题
a. 时间序列引用只会，引用切片，不会复制数据，新建数组，不存在内存复制开销

q. 错误处理实现如何优化
a. 考虑抛弃原有的错误处理逻辑改用新的逻辑
   ```
   a = 1/0

   # 这定义了一个错误处理语句块，脚本运行抛出异常时会立即终止，进入到这个语句块的定义去执行，如果没有这个定义抛错立即终止程序运行
   -- ERROR --
   if _error:
       return 0
   # 用内置函数exit('除0错误')也可以立即终止运行
   -- ERROR_END --
   return 1
   ```

   这个宏具体做了些什么呢？简单来说，是在数据处理脚本上挂载了一个_on_error函数，当发生异常解释器会调用_on_error函数，数据处理脚本中不可以直接定义函数，但解释器保留了这个能力，_error则是一个 预定义的内置可变量，解释器会将错误赋值给他

q. 还有哪些提前定义的内置变量
a. _args, args_names, _returns, _returns_names

q. 没有循环，如何实现循环的功能
a. 虽然没有循环，但是内置map 函数，filter 函数 等数组操作函数,没有循环减少了编程的复杂度，更关注结果，而不关注如何做

q. 数据处理脚本中不支持函数定义怎么 使用map
a. 移除函数定义但增加lamda 表达式
   ```
   map([1,2,3], x -> x * 2)
   filter([1,2,3], x -> x > 1)
   reduce([1,2,3], (x,y) -> x + y)
   ```
   会增加一些内置函数来生成指定的数据结构，比如
   ```
   # 代表生成长度10，0填充的数组
   arrar1 = Array(10,0)

   # 代表生成长度5，内容是12345的数组
   arrar2 = [1,2,3,4,5]

   array3 = map(arrar1,(x,index) = index + x)

   array4 = filter(array3, x -> x < 3)

   array5 = reduce(array4, (x,y) -> x + y)
   ```

   q. 包如何管理？
   a. 作为一个领域专用语言不需要复杂的包管理流程以及互相引用，只需要在解释器编排好脚本顺序即可
